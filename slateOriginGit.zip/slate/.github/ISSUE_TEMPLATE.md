<!--
⚠️  READ THIS BEFORE SUBMITTING ⚠️

• Prefix questions and feature requests with either Question: or Feature:
• If this is a bug report or question about an issue you're having, make sure to include the form below in your issue
-->

Operating system: ✍️ TODO
Last upstream commit (run `git log --author="Robert Lord" | head -n 1`): ✍️ TODO
Browser version(s): ✍️ TODO
Ruby version (run `ruby -v`):  ✍️ TODO

---

✍️ TODO write your issue here